function output = PowerLawTr(input, gamma)
% Returns transformed image by power law transformation with gamma where INPUT is a gray scale input image

% Complete the remaining part
% transformation
output= input.^(gamma);